import type { DefaultSession } from 'next-auth';

declare module 'next-auth' {
  interface Session {
    user: DefaultSession['user'] & {
      id: string;
      role: string;
      isGuest: boolean;
    };
    accessToken?: string;
    refreshToken?: string;
  }

  interface User {
    id: string;
    role: string;
    isGuest: boolean;
    accessToken: string;
    refreshToken: string;
  }
}

declare module 'next-auth/jwt' {
  interface JWT {
    id: string;
    role: string;
    isGuest: boolean;
    accessToken: string;
    refreshToken: string;
  }
}
